app.factory("eventservice",function($resource){
    return {
           getEvent : function()
           {
           return $resource('/routing/files/:id', {id:'@id'}).get({id:'1.json'});
           }
    };
});